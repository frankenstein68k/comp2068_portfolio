/* 
script.js / Neil MacKenzie / COMP 2068 Personal Portfolio / provides the code to create interactive web pages / Javascript
*/























